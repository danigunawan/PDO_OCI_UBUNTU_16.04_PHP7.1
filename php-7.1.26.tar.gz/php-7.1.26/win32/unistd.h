#ifndef _PHP_WIN32_UNISTD_H
#define _PHP_WIN32_UNISTD_H
PHPAPI int usleep(unsigned int useconds);
#endif
